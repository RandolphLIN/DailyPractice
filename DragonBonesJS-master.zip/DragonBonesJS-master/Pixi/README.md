# DragonBones Pixi library

## [Demos](./Demos/)
* [Get DragonBones build js.](https://github.com/DragonBones/DragonBonesJS/tree/master/DragonBones/build/)
* [Get DragonBones Pixi build js.](https://github.com/DragonBones/DragonBonesJS/tree/master/Pixi/build/)
* [Get Pixi build js.](https://github.com/pixijs/pixi.js/)