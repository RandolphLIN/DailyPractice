'use strict';

describe('PIXI.loaders.Loader', function ()
{
    it('should exist', function ()
    {
        expect(PIXI.loaders.Loader).to.be.a('function');
    });
});
